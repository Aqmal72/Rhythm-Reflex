#include "Timer.h"

Timer::Timer(int seconds)
    : startTime(0), durationSeconds(seconds), running(false) {}

void Timer::start() {
    startTime = time(NULL);
    running = true;
}

void Timer::reset(int seconds) {
    durationSeconds = seconds;
    start();
}

bool Timer::isRunning() const {
    return running;
}

int Timer::getElapsed() const {
    if (!running) return 0;
    return (int)difftime(time(NULL), startTime);
}

int Timer::timeLeft() const {
    if (!running) return durationSeconds;
    int remaining = durationSeconds - getElapsed();
    return (remaining > 0) ? remaining : 0;
}

bool Timer::isTimeUp() const {
    return timeLeft() <= 0;
}

int Timer::getDuration() const {
    return durationSeconds;
}
