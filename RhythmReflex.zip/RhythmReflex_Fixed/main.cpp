#include <graphics.h>
#include <conio.h>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <windows.h>
#include <mmsystem.h>

#include "Timer.h"
#include "Scoreboard.h"
#include "HighlightArea.h"
#include "Pointer.h"
#include "UIHelper.h" 

#pragma comment(lib, "winmm.lib")

static void delay_ms(int ms) {
    Sleep(ms);
}

// Draw solid donut (ring) with inner background
static void drawSolidDonut(int cx, int cy, int outerR, int innerR, int ringColor, int bgColor) {
    setfillstyle(SOLID_FILL, ringColor);
    setcolor(ringColor);
    fillellipse(cx, cy, outerR, outerR);

    setfillstyle(SOLID_FILL, bgColor);
    setcolor(bgColor);
    fillellipse(cx, cy, innerR, innerR);
}

int main() {
    srand((unsigned)time(0));

    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*)"");

    setbkcolor(WHITE);
    cleardevice();

    const int cx = getmaxx() / 2;
    const int cy = getmaxy() / 2;

    const int innerR = 90;
    const int outerR = 140;
    const int pointerPathR = (innerR + outerR) / 2;

    HighlightArea zone(cx, cy, innerR, outerR);
    Pointer pointer(cx, cy, pointerPathR, 10, WHITE);
    Scoreboard scoreboard;

    bool retry = true;
    int page = 0;
    setvisualpage(page);
    setactivepage(page);

    while (retry) {
        Timer timer(30);
        timer.start();

        scoreboard.reset();
        zone.randomize();
        pointer.randomizeSpeed(4.0f, 9.0f);

        int shakeFrames = 0;

        // =========================
        // START SCREEN
        // =========================
        page = 0;
        setvisualpage(page);
        setactivepage(page);

        while (true) {
            setactivepage(page);
            cleardevice();

            UIHelper::drawLargeTitleImage(cx, cy - 50);
            UIHelper::drawTextCentered(cx, cy + 70, "Press ENTER to start", BLACK, 2);

            setvisualpage(page);
            page = 1 - page;

            if (kbhit()) {
                int key = getch();
                if (key == 13) break; // ENTER
            }
            delay_ms(16);
        }

        // =========================
        // MAIN GAME LOOP
        // =========================
        while (!timer.isTimeUp()) {
            setactivepage(page);
            setviewport(0, 0, getmaxx(), getmaxy(), 1);
            clearviewport();

            int dx = 0, dy = 0;
            if (shakeFrames > 0) {
                dx = (rand() % 7) - 3;
                dy = (rand() % 7) - 3;
                shakeFrames--;
            }

            setviewport(dx, dy, getmaxx() + dx, getmaxy() + dy, 1);

            drawSolidDonut(cx, cy, outerR, innerR, COLOR(80, 235, 240), WHITE);
            zone.draw(COLOR(55, 125, 170));

            pointer.rotate();
            pointer.draw();

            setviewport(0, 0, getmaxx(), getmaxy(), 1);

            // UI
            UIHelper::drawSmallTitleImage(cx, cy);

            char t[32];
            UIHelper::makeTimerText(t, sizeof(t), timer.timeLeft());
            UIHelper::drawTextRight(getmaxx(), 10, t, RED, 2, 10);

            scoreboard.drawCenter(cx, cy);
            scoreboard.drawAddPopup(cx, cy, outerR);

            UIHelper::drawTextCentered(getmaxx() / 2, getmaxy() - 40,
                "Hit [SPACE] when the pointer is in the zone", BLACK, 2);

            scoreboard.tickMessage();

            setvisualpage(page);
            page = 1 - page;

            // =========================
            // INPUT HANDLING
            // =========================
            if (kbhit()) {
                int key = getch();

                if (key == ' ') {
                    while (kbhit()) getch(); // clear buffer
                    pointer.freeze();

                    bool ok = pointer.isInside(zone);
                    scoreboard.recordAttempt(ok);

                    if (ok) {
                        scoreboard.successfulHit();
                        zone.randomize();
                        PlaySound("point_up2.wav", NULL, SND_FILENAME | SND_ASYNC);
                    } else {
                        scoreboard.missedHit();
                        PlaySound("point_miss2.wav", NULL, SND_FILENAME | SND_ASYNC);
                        shakeFrames = 15;
                        delay_ms(1000);
                    }

                    pointer.unfreeze();
                } else if (key == 'q' || key == 'Q') {
                    timer.reset(0);
                }
            }

            delay_ms(16);
        }

        // =========================
        // END SCREEN
        // =========================
        page = 0;
        setvisualpage(page);
        setactivepage(page);

        bool waiting = true;
        while (waiting) {
            setactivepage(page);
            cleardevice();

            UIHelper::drawTextCentered(cx, 160, "TIME'S UP!", RED, 4);

            char finalScore[64];
            sprintf(finalScore, "Final Score: %d", scoreboard.getScore());
            UIHelper::drawTextCentered(cx, 220, finalScore, BLACK, 2);

            char acc[80];
            sprintf(acc, "Accuracy: %.1f%%", scoreboard.getAccuracy());
            UIHelper::drawTextCentered(cx, 245, acc, BLACK, 2);

            UIHelper::drawTextCentered(cx, 300, "Press R to Retry or Q to Quit", BLACK, 2);

            setvisualpage(page);
            page = 1 - page;

            if (kbhit()) {
                int key = getch();
                if (key == 'r' || key == 'R') {
                    retry = true;
                    waiting = false;
                } else if (key == 'q' || key == 'Q') {
                    retry = false;
                    waiting = false;
                }
            }
            delay_ms(16);
        }
    }

    closegraph();
    return 0;
}