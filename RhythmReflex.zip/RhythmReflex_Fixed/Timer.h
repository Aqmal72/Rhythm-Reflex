#ifndef TIMER_H
#define TIMER_H

#include <ctime>

class Timer {
private:
    time_t startTime;
    int durationSeconds;
    bool running;

public:
    Timer(int seconds = 60);

    void start();
    void reset(int seconds);

    bool isRunning() const;

    int getElapsed() const;
    int timeLeft() const;
    bool isTimeUp() const;

    int getDuration() const;
};

#endif
